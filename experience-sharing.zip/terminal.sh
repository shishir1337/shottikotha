npm install @supabase/supabase-js uuid
